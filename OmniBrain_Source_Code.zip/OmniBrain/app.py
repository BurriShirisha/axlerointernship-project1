from fastapi import FastAPI
from pydantic import BaseModel
from graph import build_graph

app = FastAPI(title="OmniBrain")
graph = build_graph()

class Query(BaseModel):
    query: str

@app.get("/")
def root():
    return {
        "project": "OmniBrain",
        "status": "running"
    }

@app.post("/ask")
def ask(body: Query):
    result = graph.invoke({"query": body.query})

    return {
        "answer": result.get("answer", ""),
        "route": result.get("route", []),
        "evidence": result.get("evidence", [])
    }
