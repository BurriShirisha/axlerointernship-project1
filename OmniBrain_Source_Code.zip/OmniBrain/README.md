# OmniBrain — Agentic Multi-Modal RAG Orchestrator

Academic reference implementation.

## Run
```bash
python -m venv .venv
pip install -r requirements.txt
# create .env from .env.example
python ingest.py financial_report.pdf
uvicorn app:app --reload
```

Open http://127.0.0.1:8000/docs

The demo uses FAISS for text retrieval and SQLite for structured stock data.
The vision interface uses an OpenAI-compatible VLM when OPENAI_API_KEY is configured.
