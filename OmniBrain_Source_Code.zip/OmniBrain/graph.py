from langgraph.graph import StateGraph, END
from models import OmniState
from agents import SearchAgent, SQLAgent, grounded_synthesis

search_agent = SearchAgent()

def supervisor(state: OmniState):
    q = state["query"].lower()
    route = ["search"]

    if any(x in q for x in
           ["stock", "price", "ticker", "historical", "market"]):
        route.append("sql")

    return {"route": route}

def search_node(state):
    evidence = search_agent.run(state["query"])
    return {"evidence": evidence}

def sql_node(state):
    result = SQLAgent().run(state["query"])
    return {
        "evidence": state.get("evidence", []) + [result]
    }

def synthesize_node(state):
    answer = grounded_synthesis(
        state["query"],
        state.get("evidence", [])
    )
    return {"answer": answer}

def build_graph():
    graph = StateGraph(OmniState)

    graph.add_node("supervisor", supervisor)
    graph.add_node("search", search_node)
    graph.add_node("sql", sql_node)
    graph.add_node("synthesize", synthesize_node)

    graph.set_entry_point("supervisor")
    graph.add_edge("supervisor", "search")

    graph.add_conditional_edges(
        "search",
        lambda s: "sql" if "sql" in s.get("route", [])
        else "synthesize",
        {
            "sql": "sql",
            "synthesize": "synthesize"
        }
    )

    graph.add_edge("sql", "synthesize")
    graph.add_edge("synthesize", END)

    return graph.compile()
