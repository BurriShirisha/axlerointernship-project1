import os, json, argparse
import fitz
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)

def extract_pdf(pdf_path):
    doc = fitz.open(pdf_path)
    chunks, images = [], []
    for pno, page in enumerate(doc, start=1):
        text = page.get_text("text")
        if text.strip():
            chunks.append({"page": pno, "text": text[:5000]})

        for img_no, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            pix = fitz.Pixmap(doc, xref)
            path = os.path.join(DATA_DIR, f"page_{pno}_img_{img_no}.png")
            if pix.n < 4:
                pix.save(path)
            else:
                pix = fitz.Pixmap(fitz.csRGB, pix)
                pix.save(path)
            images.append({"page": pno, "path": path})

    return chunks, images

def build_index(chunks):
    model = SentenceTransformer("all-MiniLM-L6-v2")
    vectors = model.encode([x["text"] for x in chunks],
                           normalize_embeddings=True)
    vectors = np.asarray(vectors, dtype="float32")

    index = faiss.IndexFlatIP(vectors.shape[1])
    index.add(vectors)
    faiss.write_index(index, os.path.join(DATA_DIR, "text.index"))

    with open(os.path.join(DATA_DIR, "chunks.json"), "w",
              encoding="utf-8") as f:
        json.dump(chunks, f, indent=2, ensure_ascii=False)

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("pdf")
    args = parser.parse_args()

    chunks, images = extract_pdf(args.pdf)
    build_index(chunks)

    with open(os.path.join(DATA_DIR, "images.json"), "w") as f:
        json.dump(images, f, indent=2)

    print(f"Indexed {len(chunks)} text chunks and {len(images)} images.")
