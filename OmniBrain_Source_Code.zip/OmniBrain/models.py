from typing import TypedDict, List, Dict, Any

class OmniState(TypedDict, total=False):
    query: str
    route: List[str]
    evidence: List[Dict[str, Any]]
    answer: str
