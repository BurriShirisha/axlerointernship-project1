def validate_grounding(answer: str, evidence: list):
    if not answer.strip():
        return {"ok": False, "reason": "Empty answer"}

    if not evidence:
        return {"ok": False, "reason": "No evidence"}

    return {
        "ok": True,
        "reason": "Answer contains retrieved evidence"
    }

def block_unsafe(text: str):
    banned = [
        "ignore previous instructions",
        "reveal system prompt"
    ]

    return not any(
        word in text.lower() for word in banned
    )
