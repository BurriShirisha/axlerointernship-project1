import os, json, sqlite3, base64
from dotenv import load_dotenv
from sentence_transformers import SentenceTransformer
import faiss
import numpy as np
from openai import OpenAI

load_dotenv()

client = None
if os.getenv("OPENAI_API_KEY"):
    client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

class SearchAgent:
    def __init__(self):
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.index = faiss.read_index("data/text.index")
        with open("data/chunks.json", encoding="utf-8") as f:
            self.chunks = json.load(f)

    def run(self, query, k=5):
        q = self.model.encode(
            [query], normalize_embeddings=True
        ).astype("float32")

        _, ids = self.index.search(q, k)

        return [
            {
                "type": "text",
                "page": self.chunks[i]["page"],
                "content": self.chunks[i]["text"]
            }
            for i in ids[0] if i >= 0
        ]

class SQLAgent:
    def run(self, question):
        conn = sqlite3.connect("data/market.db")
        cur = conn.cursor()

        cur.execute(
            "CREATE TABLE IF NOT EXISTS stock_prices "
            "(date TEXT, ticker TEXT, close REAL)"
        )

        ticker = "AAPL" if "apple" in question.lower() else "MSFT"

        cur.execute(
            "SELECT date,ticker,close FROM stock_prices "
            "WHERE ticker=? ORDER BY date DESC LIMIT 10",
            (ticker,)
        )

        rows = cur.fetchall()
        conn.close()

        return {
            "type": "sql",
            "question": question,
            "rows": rows
        }

class VisionAgent:
    def run(self, image_path, question):
        if not client:
            return {
                "type": "vision",
                "image": image_path,
                "content": "VLM disabled. Configure OPENAI_API_KEY."
            }

        with open(image_path, "rb") as f:
            b64 = base64.b64encode(f.read()).decode()

        response = client.chat.completions.create(
            model=os.getenv("VISION_MODEL", "gpt-4o"),
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": question},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/png;base64,{b64}"
                            }
                        }
                    ]
                }
            ],
            max_tokens=800
        )

        return {
            "type": "vision",
            "image": image_path,
            "content": response.choices[0].message.content
        }

def grounded_synthesis(query, evidence):
    context = "\n\n".join(
        f"[{i+1}] {e}" for i, e in enumerate(evidence)
    )

    if not client:
        return "LLM disabled. Retrieved evidence:\n\n" + context

    prompt = f'''
You are a financial research assistant.
Answer only from the supplied evidence.
Do not invent numbers.
If evidence is insufficient, say so.
Use citation markers such as [1], [2].

Question:
{query}

Evidence:
{context}
'''

    response = client.chat.completions.create(
        model=os.getenv("CHAT_MODEL", "gpt-4o-mini"),
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1
    )

    return response.choices[0].message.content
